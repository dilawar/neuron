Authors of SystemC / TLM
========================

 *  Daniel Aarno,                Intel Corporation
 *  James Aldis,                 Texas Instruments
 *  Guillaume Audeon,            ARM Ltd.
 *  John Aynsley,                Doulos, Inc.
 *  Mohamed Bamakhrama,          Intel Corporation
 *  Bishnupriya Bhattacharya,    Cadence Design Systems, Inc.
 *  David Black,                 Doulos, Inc.
 *  Bill Bunton,                 XtremeEDA Corp.
 *  Gene Bushuyev,               Synopsys, Inc.
 *  Mark Burton,                 GreenSocs
 *  Jerome Cornet,               STMicroelectronics
 *  Guillaume Delbergue,         GreenSocs
 *  Jack Donovan,                XtremeEDA Corp.
 *  Ali Dasdan,                  Synopsys, Inc.
 *  Alan Fitch,                  Doulos, Inc.
 *  Ralph Görgen,                NXP Semiconductors
 *  Abhijit Ghosh,               Synopsys, Inc.
 *  Andy Goodrich,               Forte Design Systems, Inc.
 *  Robert Günzel,               GreenSocs
 *  Andreas Hedström,            Intel Corporation
 *  Philipp A. Hartmann,         Intel Corporation
 *  Gino van Hauwermeiren,       NXP Semiconductors N.V.
 *  Andreas Hedstrom,            Intel Corporation
 *  Ulrich Holtmann,             Synopsys, Inc.
 *  Martin Janssen,              Synopsys, Inc.
 *  Vijay Kumar,                 CoWare, Inc.
 *  Joshua Landau,               ARM Ltd.
 *  Stan Y. Liao,                Synopsys, Inc.
 *  David Long,                  Doulos, Inc.
 *  Torsten Mähne,               Bern University of Applied Sciences
 *  Marcelo Montoreano,          Synopsys, Inc.
 *  Eric Paire,                  STMicroelectronics
 *  Sonal Podder,                Intel Corporation
 *  Roman I Popov,               Intel Corporation
 *  Cesar Quiroz,                CoWare, Inc.
 *  Amit Rao,                    Synopsys, Inc.
 *  Harish Sarin,                CoWare, Inc.
 *  Stuart Swan,                 Cadence Design Systems, Inc.
 *  Thomas Uhle,                 Fraunhofer-Gesellschaft
 *  Bart Vanthournout,           CoWare, Inc.
 *  Dirk Vermeersch,             CoWare, Inc.
 *  Trevor Wieman,               Intel Corporation
 *  Charles Wilson,              XtremeEDA Corp.
